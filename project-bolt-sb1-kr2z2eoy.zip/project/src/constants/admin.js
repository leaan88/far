export const ADMIN_CREDENTIALS = {
  username: 'Admin',
  password: 'Farma22'
};